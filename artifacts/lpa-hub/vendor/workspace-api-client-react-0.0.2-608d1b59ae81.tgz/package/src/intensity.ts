/** Pure, shared Build intensity calculations. No device or React dependencies. */
export type IntensityMethod = "percentage" | "rpe" | "rir" | "percentage_plus_rpe" | "percentage_plus_rir";
export type LoadUnit = "kg" | "lb";
export type IntensityRange = { min: number; max: number };
export type RpeChartRow = { reps: number; rpe: number; percentage: number };
export const INTENSITY_METHODS: IntensityMethod[] = ["percentage", "rpe", "rir", "percentage_plus_rpe", "percentage_plus_rir"];
export const DEFAULT_INTENSITY_PREFERENCES = {
  defaultMethod: "percentage" as IntensityMethod, effortScale: "rpe" as "rpe" | "rir",
  unit: "lb" as LoadUnit, roundingIncrement: 5,
};
// Initial coaching reference; the persisted chart is editable by staff.
const maxPercentages = [100, 95.5, 92.2, 89.2, 86.3, 83.7, 81.1, 78.6, 76.2, 73.9, 71.6, 69.4, 67.3, 65.2, 63.2, 61.3, 59.4, 57.6, 55.8, 54.1];
export const DEFAULT_RPE_CHART: RpeChartRow[] = Array.from({ length: 10 }, (_, i) => i + 1)
  .flatMap((reps) => Array.from({ length: 11 }, (_, j) => {
    const rpe = 5 + j * 0.5;
    const index = reps - 1 + 10 - rpe;
    const lower = Math.floor(index);
    const percentage = maxPercentages[lower] + (index - lower) * (maxPercentages[lower + 1] - maxPercentages[lower]);
    return { reps, rpe, percentage: Math.round(percentage * 10) / 10 };
  }));

export function intensityRange(value: string | undefined, kind: "percent" | "rpe" | "rir"): IntensityRange | null {
  if (!value?.trim()) return null;
  const match = value.trim().replace(/[–—]/g, "-").replace(/%$/, "").match(/^(\d+(?:\.\d+)?)(?:\s*-\s*(\d+(?:\.\d+)?))?$/);
  const min = match ? Number(match[1]) : NaN;
  const max = match ? Number(match[2] ?? match[1]) : NaN;
  const bounds = { percent: [1, 120], rpe: [5, 10], rir: [0, 5] }[kind];
  if (!Number.isFinite(min) || min < bounds[0] || max > bounds[1] || min > max ||
      (kind === "rpe" && (min * 2 % 1 !== 0 || max * 2 % 1 !== 0)) ||
      (kind === "rir" && (!Number.isInteger(min) || !Number.isInteger(max)))) {
    throw new Error(kind === "percent" ? "Percentage Output must be 1–120, or a range such as 75–80." :
      kind === "rpe" ? "RPE must be 5–10 in 0.5 steps, or a range such as 7–8." :
        "RIR must be a whole number from 0–5, or a range such as 1–2.");
  }
  return { min, max };
}
export const rpeToRir = (rpe: number) => 10 - rpe;
export const rirToRpe = (rir: number) => 10 - rir;
export function roundLoad(load: number, increment: number) {
  if (!Number.isFinite(load) || load < 0 || !Number.isFinite(increment) || increment <= 0) throw new Error("Use a positive rounding increment and a nonnegative load.");
  return Math.round(Math.round(load / increment) * increment * 1000) / 1000;
}
export function percentageLoad(oneRepMax: number, percentage: number, increment: number) {
  if (!Number.isFinite(oneRepMax) || oneRepMax <= 0 || percentage < 1 || percentage > 120) throw new Error("Enter a valid 1RM and percentage.");
  return roundLoad(oneRepMax * percentage / 100, increment);
}
export const convertLoad = (load: number, from: LoadUnit, to: LoadUnit) => from === to ? load : from === "kg" ? load * 2.2046226218 : load / 2.2046226218;
export function estimateOneRepMax(weight: number, reps: number, effort: { rpe?: number | null; rir?: number | null }) {
  const rir = effort.rir ?? (effort.rpe != null ? rpeToRir(effort.rpe) : 0);
  if (!Number.isFinite(weight) || weight <= 0 || !Number.isInteger(reps) || reps < 1 || !Number.isFinite(rir) || rir < 0 || rir > 5) throw new Error("A positive completed load, reps, and valid effort are required.");
  return { value: Math.round(weight * (1 + (reps + rir) / 30) * 100) / 100, lessReliable: reps > 10 };
}
export function chartPercentage(chart: RpeChartRow[], reps: number, rpe: number) {
  return chart.find((row) => row.reps === reps && row.rpe === rpe)?.percentage ?? null;
}
type Item = { options?: { intensityMethod?: IntensityMethod | null }; setValues: { setNumber: number; property: string; value: string }[] };
type Profile = { value: number; unit: LoadUnit };
type Preferences = { unit: LoadUnit; roundingIncrement: number; defaultMethod?: IntensityMethod };
export function prescribeIntensity(item: Item, setNumber: number, profile: Profile | undefined, preferences: Preferences, chart: RpeChartRow[]) {
  const value = (property: string) => item.setValues.find((v) => v.setNumber === setNumber && v.property === property)?.value;
  const enteredPercent = intensityRange(value("percent"), "percent");
  const enteredRpe = intensityRange(value("rpe"), "rpe");
  const enteredRir = intensityRange(value("rir"), "rir");
  const method = item.options?.intensityMethod ?? (enteredPercent ? enteredRpe ? "percentage_plus_rpe" : enteredRir ? "percentage_plus_rir" : "percentage" : enteredRpe ? "rpe" : enteredRir ? "rir" : preferences.defaultMethod);
  const percent = method?.includes("percentage") ? enteredPercent : null;
  const rpe = method?.includes("rpe") ? enteredRpe : null;
  const rir = method?.includes("rir") ? enteredRir : null;
  const repsText = value("reps") ?? "";
  const reps = Number(repsText.split("-")[0]);
  const effort = rpe ?? (rir ? { min: rirToRpe(rir.max), max: rirToRpe(rir.min) } : null);
  const chartMin = effort ? chartPercentage(chart, reps, effort.min) : null;
  const chartMax = effort ? chartPercentage(chart, reps, effort.max) : null;
  const suggestedPercent = percent ?? (chartMin != null && chartMax != null ? { min: chartMin, max: chartMax } : null);
  const oneRepMax = profile ? convertLoad(profile.value, profile.unit, preferences.unit) : null;
  const loadMin = oneRepMax && suggestedPercent ? percentageLoad(oneRepMax, suggestedPercent.min, preferences.roundingIncrement) : null;
  const loadMax = oneRepMax && suggestedPercent ? percentageLoad(oneRepMax, suggestedPercent.max, preferences.roundingIncrement) : null;
  const overrideText = value("weight")?.trim();
  const override = overrideText && Number.isFinite(Number(overrideText)) && Number(overrideText) >= 0 ? Number(overrideText) : null;
  return { method, percent, rpe, rir, suggestedPercent, oneRepMax, loadMin, loadMax, load: override ?? loadMin, unit: preferences.unit, missingOneRepMax: !!suggestedPercent && !oneRepMax };
}
